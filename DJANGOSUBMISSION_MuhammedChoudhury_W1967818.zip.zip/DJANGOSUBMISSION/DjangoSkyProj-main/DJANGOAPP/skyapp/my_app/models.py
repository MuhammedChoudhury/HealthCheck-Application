from django.db import models
from django.contrib.auth.models import User


# Create your models here.
##############################
#  Editors: Mikayel, Umar,   #
##############################

#Mikayel Stuff

# This is for storing a user's health card votes
class HealthCard(models.Model):
    # Links to a user - if user is deleted, their health card goes too
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    # Saves when this was created
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Health Card {self.user.username} - {self.created_at.date()}"

# This lets people vote with colors (red, amber, green)
class Vote(models.Model):
    # The colors mean red=bad, amber=okay, green=good, they're also numbered, 1 is red 2 is amber 3 is green
    COLOR_CHOICES = [
        (1, 'Red'),
        (2, 'Amber'),
        (3, 'Green'),
    ]

    # associates the vote to a healthcard, if it's deleted, this gets removed.
    health_card = models.ForeignKey(HealthCard, on_delete=models.CASCADE, related_name='votes')
    # associates the vote to a user, if they are deleted, this gets deleted.
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    # adds a field for what area they're voting on (Delivering Value, Teamwork, etc.)
    category = models.CharField(max_length=100)
    # Adds a field for the color they chose
    color = models.IntegerField(choices=COLOR_CHOICES)
    # Adds the feedback they wrote as a field for the vote
    feedback = models.TextField(blank=True, null=True)
    # Creates a field that holds a timestamp of when the vote was created
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        # keeps it unique so one healthcard can only have one vote per category per user
        unique_together = ['health_card', 'category']

    def get_color_display_name(self):
        # Turns the number into a color name
        return dict(self.COLOR_CHOICES)[self.color]
    
# Department to hold the teams
class Department(models.Model):
    # adds a field for the department as a name, can be anything
    name = models.CharField(max_length=100)
    
    # returns the name of the department
    def __str__(self):
        return self.name
    
    def team_count(self):
        # Counts how many teams are in this department
        return self.teams.count()
    
    def can_add_team(self):
        # checks if we can add a new team to the current department
        return self.team_count() < 5

# For groups of people working together
class Team(models.Model):
    # What the team is called
    name = models.CharField(max_length=100)
    
    # associates the team to the department
    # If department is deleted, its teams are deleted too
    department = models.ForeignKey(Department, on_delete=models.CASCADE, related_name='teams', null=True, blank=True)
    
    # The people in this team
    members = models.ManyToManyField(User, related_name='teams')

    def member_count(self):
        # Counts how many members are in this team
        return self.members.count()
    
    def add_member(self, user):
        # Adds someone to the team if there's room
        if self.members.count() >= 5:
            raise ValueError("Cannot add more than 5 members to a team.")
        
        self.members.add(user)

    def remove_member(self, user):
        # Takes someone off the team
        if user in self.members.all():
            self.members.remove(user)
        else:
            raise ValueError("User is not a member of this team.")
    
    def __str__(self):
        return self.name

#End of Mikayel Stuff

#umar (w1948131) #Employee / Profile to hold the user information
class Employee(models.Model):
    ROLE_CHOICES = [
        ('engineer', 'Engineer'),
        ('teamleader', 'Team Leader'),
        ('departmentleader', 'Department Leader'),
        ('seniormanager', 'Senior Manager'),
        ('admin', 'Admin'),
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE, null=True, blank=True)
 
   #umar(w1941831)
    email = models.EmailField(unique=True)
    first_name = models.CharField(max_length=50, blank=True)
    last_name = models.CharField(max_length=50, blank=True)
    username = models.CharField(max_length=50, null=True) #set null = true so username can be added without a value
    password = models.CharField(max_length=50, null=True) #set null = true so username and password can be added without a value
    team_number = models.CharField(max_length=50)
    department_number = models.CharField(max_length=50)
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='engineer')
    registered = models.BooleanField(default=False)
 
 
    def __str__(self):
        return self.email