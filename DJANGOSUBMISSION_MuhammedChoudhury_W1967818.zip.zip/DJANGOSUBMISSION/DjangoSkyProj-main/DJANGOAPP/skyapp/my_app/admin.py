from django.contrib import admin
from .models import HealthCard, Vote, Team, Department, Employee

# Register your models here.


#Mikayel Stuff

# Shows votes inside health cards
class VoteInline(admin.TabularInline):
    model = Vote
    extra = 0  # No empty forms

# Shows teams inside departments
class TeamInline(admin.TabularInline):
    model = Team
    extra = 1
    fields = ('name', 'display_members',)
    readonly_fields = ('display_members',)

    # Load members efficiently
    def get_queryset(self, request):
        queryset = super().get_queryset(request)
        queryset = queryset.prefetch_related('members')
        return queryset

    # Show who's in the team
    def display_members(self, obj):
        if not obj.id:
            return "Add members to see them in the list"
        
        members = obj.members.all()
        if not members:
            return "No members for this team"
        
        member_names = [user.username for user in members]
        return ", ".join(member_names)
    display_members.short_description = 'Team Members'

# Shows the members inside of a team
class MembersInLine(admin.TabularInline):
    model = Team.members.through
    extra = 1
    field = "Team member"
    fields_plural = "Team members"


    readonly_fields = ()

    def get_queryset(self, request):
        queryset = super().get_queryset(request)
        return queryset.select_related('user')

# Health card management in admin
@admin.register(HealthCard)
class HealthCardAdmin(admin.ModelAdmin):
    list_display = ('user', 'created_at', 'get_vote_count')
    search_fields = ('user__username', 'user__first_name', 'user__last_name')
    list_filter = ('created_at',)
    inlines = [VoteInline]
    
    # Count how many votes on this card
    def get_vote_count(self, obj):
        return obj.votes.count()
    get_vote_count.short_description = 'Votes'


# Vote management in admin
@admin.register(Vote)
class VoteAdmin(admin.ModelAdmin):
    list_display = ('category', 'get_color_display', 'health_card', 'user', 'created_at')
    list_filter = ('category', 'color', 'created_at')
    search_fields = ('user__username', 'health_card__user__username', 'feedback')
    
    # Convert number to color name
    def get_color_display(self, obj):
        # Maps the color to a number string
        colors = {1: 'Red', 2: 'Amber', 3: 'Green'}
        return colors.get(obj.color, 'Unknown')
    get_color_display.short_description = 'Color'

# Team management in admin
@admin.register(Team)
class TeamAdmin(admin.ModelAdmin):
    list_display = ('name', 'department', 'display_members',)
    inlines = [MembersInLine]
    list_filter = ('department',)
    search_fields = ('name', 'members__username',)

    def display_members(self, obj):
        members = obj.members.all()
        if not members:
            return "No members for this team"
        member_names = [user.username for user in members]
        return ", ".join(member_names)
    display_members.short_description = 'Team Members'

    # Loads members of the team
    def get_queryset(self, request):
        queryset = super().get_queryset(request)
        return queryset.prefetch_related('members')

# Department management for admin
@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ('name', 'get_team_count', 'teams')
    inlines = [TeamInline]
    search_fields = ('name',)
    ordering = ('name',)

    # Load teams and members, this way you can access the department
    # and all the information is there, just for nicer viewing.
    def get_queryset(self, request):
        queryset = super().get_queryset(request)
        queryset = queryset.prefetch_related('teams', 'teams__members')
        return queryset
    
    # Lists all teams in the department
    def teams(self, obj):
        teams = obj.teams.all()
        if not teams:
            return "No teams in this department"
        
        team_names = [team.name for team in teams]
        return ", ".join(team_names)

    # Counts the teams inside the department
    def get_team_count(self, obj):
        return obj.team_count()
    get_team_count.short_description = 'Team Count'
    
#End of Mikayel Stuff

@admin.register(Employee)
class EmployeeAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'email', 'team_number', 'department_number', 'role')
    search_fields = ('first_name', 'last_name', 'email')
    list_filter = ('team_number', 'department_number', 'role')
    ordering = ('first_name', 'last_name')